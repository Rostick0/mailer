export const setClassName = (className) => {
  if (className) return " " + className;

  return "";
};
