export const URL_BACKEND: string = 'https://proxy.innolingvo.ru/ru/api/';
export const FORMAT_API_KEY = '?format=json&api_key=6ki6ryxudngehdwxo679gsnaxcz468ikx47a1wce&';
// 'https://jsonplaceholder.typicode.com/todos/1'
// "http://212.113.120.254:8000/lists/admin/?page=call&pi=restapi";
export const LOGIN_BACKEND: string = "test";
export const PASSWORD_BACKEND: string = "0ZB87atKpMd4HP2";